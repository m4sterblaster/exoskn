#!/usr/bin/python
# -*- coding: utf-8 -*-

class SERIAL:
    class MSG:
        NAME            = chr(29)
        DATA            = chr(30)
        END             = chr(31)
